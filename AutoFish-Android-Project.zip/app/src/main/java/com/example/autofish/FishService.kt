package com.example.autofish

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import kotlin.math.sqrt

class FishService : Service() {

    companion object {
        @Volatile var level = 0f
        @Volatile var running = false
    }

    private data class Config(
        val slotX: Float, val slotY: Float,
        val useX: Float, val useY: Float,
        val threshold: Float, val delay: Float,
        val calibrate: Boolean
    )

    private var projection: MediaProjection? = null
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }

        val channel = NotificationChannel("af", "AutoFish", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val note = Notification.Builder(this, "af")
            .setContentTitle("AutoFish running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(intent.getIntExtra("code", 0), data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)
        projection = proj

        val cfg = Config(
            intent.getFloatExtra("slotX", 0f), intent.getFloatExtra("slotY", 0f),
            intent.getFloatExtra("useX", 0f), intent.getFloatExtra("useY", 0f),
            intent.getFloatExtra("threshold", 0.05f), intent.getFloatExtra("delay", 0.7f),
            intent.getBooleanExtra("calibrate", false)
        )
        running = true
        worker = Thread {
            try { fishLoop(proj, cfg) }
            catch (_: InterruptedException) {}
            catch (e: Exception) { e.printStackTrace() }
            finally { running = false }
        }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun pause(seconds: Float) = Thread.sleep((seconds * 1000).toLong())

    private fun rms(buf: ShortArray, n: Int): Float {
        var sum = 0.0
        for (i in 0 until n) { val v = buf[i] / 32768.0; sum += v * v }
        return sqrt(sum / n).toFloat()
    }

    private fun fishLoop(proj: MediaProjection, cfg: Config) {
        val capture = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val rec = AudioRecord.Builder()
            .setAudioFormat(format)
            .setAudioPlaybackCaptureConfig(capture)
            .setBufferSizeInBytes(16384)
            .build()
        rec.startRecording()
        val buf = ShortArray(1024)

        try {
            if (cfg.calibrate) {
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) level = rms(buf, n)
                }
                return
            }

            TapService.tap(cfg.slotX, cfg.slotY)      // hold the rod first
            pause(cfg.delay)

            while (running) {
                TapService.tap(cfg.useX, cfg.useY)    // cast
                val castAt = System.currentTimeMillis()

                while (running) {                      // wait for the bite sound
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    val lvl = rms(buf, n)
                    level = lvl
                    val t = (System.currentTimeMillis() - castAt) / 1000f
                    if (t < 2.5f) continue             // ignore the cast splash
                    if (lvl > cfg.threshold) break     // bite
                    if (t > 45f) break                 // timeout: reel and recast
                }
                if (!running) break

                pause(cfg.delay)                       // 0.7s, then reel
                TapService.tap(cfg.useX, cfg.useY)
                pause(cfg.delay)                       // 0.7s, then recast
            }
        } finally {
            rec.stop()
            rec.release()
        }
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        projection?.stop()
        super.onDestroy()
    }
}
