package com.example.autofish

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val fields = LinkedHashMap<String, EditText>()
    private lateinit var status: TextView
    private var calibrateMode = false
    private var peak = 0f
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("af", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }

        fun field(key: String, label: String, def: String) {
            root.addView(TextView(this).apply { text = label })
            val et = EditText(this).apply {
                setText(prefs.getString(key, def))
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            fields[key] = et
            root.addView(et)
        }
        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }

        root.addView(TextView(this).apply {
            text = "Find screen coordinates with Settings > Developer options > Pointer location."
        })
        field("slotX", "Rod hotbar slot X", "0")
        field("slotY", "Rod hotbar slot Y", "0")
        field("useX", "Use / cast button X", "0")
        field("useY", "Use / cast button Y", "0")
        field("threshold", "Bite sound threshold (calibrate to find it)", "0.05")
        field("delay", "Delay before each cast and reel (seconds)", "0.7")

        button("1. Enable tap permission (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2. Calibrate sound") { begin(true) }
        button("3. Start fishing") { begin(false) }
        button("Stop") { stopService(Intent(this, FishService::class.java)) }

        status = TextView(this).apply { text = "Idle" }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })

        handler.post(object : Runnable {
            override fun run() {
                if (FishService.running) {
                    if (FishService.level > peak) peak = FishService.level
                    status.text = "Level %.3f   Peak %.3f".format(FishService.level, peak)
                } else {
                    status.text = "Idle"
                }
                handler.postDelayed(this, 150)
            }
        })
    }

    private fun num(key: String) = fields[key]!!.text.toString().toFloatOrNull() ?: 0f

    private fun begin(calibrate: Boolean) {
        if (!calibrate) {
            if (TapService.instance == null) {
                Toast.makeText(this, "Enable AutoFish in Accessibility settings first", Toast.LENGTH_LONG).show()
                return
            }
            if (num("useX") == 0f || num("useY") == 0f || num("slotX") == 0f || num("slotY") == 0f) {
                Toast.makeText(this, "Set the rod slot and use button coordinates", Toast.LENGTH_LONG).show()
                return
            }
        }
        calibrateMode = calibrate
        peak = 0f
        getSharedPreferences("af", MODE_PRIVATE).edit().apply {
            fields.forEach { (k, v) -> putString(k, v.text.toString()) }
        }.apply()

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            askCapture()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) askCapture()
        else Toast.makeText(this, "Microphone/audio permission is needed to hear bites", Toast.LENGTH_LONG).show()
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, FishService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("calibrate", calibrateMode)
            for (k in fields.keys) i.putExtra(k, num(k))
            startForegroundService(i)
            if (!calibrateMode) moveTaskToBack(true)   // go back to Minecraft
        }
    }
}
